# STM32G431-DevBoard-V1.1
Разработка самодельной отладочной платы на базе STM32G431CBT6
![9tfpwVgcH_8](https://github.com/AnZoRiN228/STM32G431-DevBoard-V1.1/assets/48620697/e01b96cf-6a5a-4fd0-9abd-d894efcbc8f8)
![104AjUIJbhU](https://github.com/AnZoRiN228/STM32G431-DevBoard-V1.1/assets/48620697/3b256982-3894-419c-955e-379b4ec20be6)
![G_1szT0yxck](https://github.com/AnZoRiN228/STM32G431-DevBoard-V1.1/assets/48620697/10c287ff-da1b-4987-b776-5c5bd6dfe6b8)
![RXi_s--TeyI](https://github.com/AnZoRiN228/STM32G431-DevBoard-V1.1/assets/48620697/e56e2de7-31c2-486b-b9dc-b3567cedf7f0)
